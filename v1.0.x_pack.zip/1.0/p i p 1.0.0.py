print('''python in python 1.0.0 (v1.0.0\1, Mar 19 2023 15:54:50)
      Type "help", "copyright", "credits" or "license()" for more information.
      ''')
while True:
    command=input('>>>')
    if 'copyright'==command:
        print('''Copyright (c) 2001-2022 Python Software Foundation.
All Rights Reserved.

Copyright (c) 2000 BeOpen.com.
All Rights Reserved.

Copyright (c) 1995-2001 Corporation for National Research Initiatives.
All Rights Reserved.

Copyright (c) 1991-1995 Stichting Mathematisch Centrum, Amsterdam.
All Rights Reserved.
''')
